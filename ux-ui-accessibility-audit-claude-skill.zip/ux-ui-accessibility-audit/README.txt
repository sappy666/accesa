UX/UI Accessibility Audit — Skill para Claude

Creada como recurso complementario del proyecto acces.a.

INSTALACIÓN
1. Descarga el ZIP sin descomprimirlo.
2. En Claude, habilita “Ejecución de código y creación de archivos” si corresponde.
3. Ve a Personalizar > Habilidades.
4. Pulsa + > Crear habilidad > Cargar una habilidad.
5. Selecciona este ZIP y activa la skill.

La skill sirve como apoyo para auditorías UX/UI y accesibilidad. No sustituye pruebas manuales ni evaluación con tecnologías de asistencia.

Diseño / recurso: Macarena Ramdohr
