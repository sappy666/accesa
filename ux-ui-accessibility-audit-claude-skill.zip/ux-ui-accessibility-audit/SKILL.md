---
name: UX UI Accessibility Audit
description: Audita interfaces, capturas y código UX/UI con WCAG 2.2; prioriza barreras y propone correcciones concretas sin inventar hallazgos.
---

# UX/UI Accessibility Audit

## Objetivo
Ayudar a revisar interfaces web y móviles desde accesibilidad y UX/UI, usando WCAG 2.2 como referencia y separando siempre lo verificable de lo que requiere prueba manual.

## Cuándo usar esta skill
Úsala cuando la persona solicite:
- auditar una interfaz, pantalla, landing, flujo o componente;
- revisar HTML, CSS o JavaScript desde accesibilidad;
- detectar barreras de contraste, teclado, foco, formularios, semántica o responsive;
- proponer correcciones accesibles conservando la identidad visual;
- crear una checklist o plan de QA de accesibilidad.

## Flujo de auditoría
1. Identifica el contexto: tipo de interfaz, tarea principal y material disponible.
2. Revisa primero barreras que bloquean tareas.
3. Evalúa, cuando sea posible:
   - estructura semántica y jerarquía de headings;
   - navegación por teclado y orden de foco;
   - foco visible;
   - nombres accesibles y controles nativos;
   - labels, instrucciones y errores de formularios;
   - contraste de texto, controles y gráficos relevantes;
   - uso de color como único medio de información;
   - texto alternativo y contenido multimedia;
   - zoom, reflow y responsive;
   - tamaño y separación de objetivos táctiles;
   - movimiento y prefers-reduced-motion;
   - estados hover, focus, active, disabled y error;
   - claridad del lenguaje y consistencia de navegación.
4. No declares como comprobado lo que una captura o fragmento de código no permite verificar.
5. Separa los hallazgos en:
   - Confirmado
   - Requiere prueba manual
   - Recomendación de mejora
6. Prioriza cada hallazgo:
   - Crítico: bloquea una tarea o acceso esencial.
   - Alto: dificulta seriamente completar una tarea.
   - Medio: genera fricción relevante.
   - Bajo: mejora de calidad o consistencia.
7. Para cada problema entrega:
   - Hallazgo
   - Impacto para la persona usuaria
   - Referencia WCAG relacionada, si corresponde
   - Corrección concreta
   - Ejemplo de código cuando sea útil
8. Termina con una checklist breve para volver a probar.

## Principios de respuesta
- No inventes ratios de contraste ni resultados de tests.
- No uses ARIA cuando un elemento HTML nativo resuelva el problema.
- Mantén la apariencia visual original siempre que no cree una barrera.
- Evita afirmar que un sitio es “100% accesible”.
- Una auditoría automática no sustituye pruebas con teclado, zoom, lector de pantalla y personas usuarias.
- Explica en lenguaje claro y accionable.

## Formato recomendado

### Resumen
Breve síntesis del estado de la interfaz.

### Hallazgos prioritarios
| Prioridad | Hallazgo | Impacto | Referencia | Corrección |
|---|---|---|---|---|

### Correcciones listas para implementar
Incluye snippets solo cuando aporten valor.

### Pruebas manuales pendientes
Lista pasos reproducibles y resultado esperado.

### Checklist final
Checklist corta para desktop y móvil.
